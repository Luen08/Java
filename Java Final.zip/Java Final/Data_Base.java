import java.util.ArrayList;
import java.util.Objects;

public class Data_Base {
    public static final ArrayList<Usuario> users = new ArrayList<>();
    
    private static void CrearObjetos() {
        users.add(new Usuario("Louen","cjoxvwdk222",500.0));
    }
    
    public static void Start(){
        CrearObjetos();
    }
    
    public static Boolean findUser(String nNick){
        for(int i = 0; i < users.size(); i++){ // recorrer el array comprobamos si existe usuario
            if(users.get(i).getNick().equals(nNick)){
                Main.ind = i; //si encuentra uno, actualiza la variable en Main
                return true;
            }
        }
        System.out.println(Main.ROJO+"Usuario no encontrado"+Main.RESET);
        return false;                   //si no encuentra retorna false
    }
    
    public static Boolean checkPwd(){
        for(int i = 0; i<3; i++){ //pregunta 3 veces 
            
            Main.pwd = Utilidades.nextPwd(Main.VERDE+"Ingresa tu contraseña: "+Main.RESET);// BANK UTIL CONTRASEÑA
            if(Objects.equals(Main.pwd, users.get(Main.ind).getPwd())){
                //si son iguales las contraseñas igualamos la variable saldo al saldo que tiene ingresado
                Main.saldo = users.get(Main.ind).saldo;
                return true;
            }
            if(i!=2){
                System.out.println(Main.ROJO+"Contraseña incorrecta"+Main.RESET);
            }
        }
        System.out.println("Ingresaste 3 veces contraseña incorrecta...");
        System.out.println("Has superado el limite de intentos...");
        return false; // SI LAS CONTRASEÑAS NO SON IGUALES RETORNA FALSE
    }
    
    public static Boolean setNewSaldo(Double saldo){
        //si el nombre de usuario y la contraseña son iguales guardamos el saldo al usuario
        if(Objects.equals(Main.pwd, users.get(Main.ind).getPwd()) && Objects.equals(Main.nick, users.get(Main.ind).getNick())){
            users.get(Main.ind).saldo = saldo;
            return true;
            
        }
        //si algo no funciona
        return false;
    }

    public static Boolean findUserLog(String usuarioNuevo){
        for(int i = 0; i < users.size();i++){
            if(users.get(i).getNick().equals(usuarioNuevo)){
                System.out.println(Main.ROJO+"Ya cuenta con un usuario"+Main.RESET);
                return false;
            }
        }
        return true;
    }

    public static Boolean findUserTrans(String usuarioTrans){
        for(int i = 0; i < users.size();i++){
            if(users.get(i).getNick().equals(usuarioTrans)){
                Main.indTrans = i;
                System.out.println("Usuario encontrado");
                return true;
            }
        }
        System.out.println("Usuario inexistente");
        return false;
    }

    public static Boolean registro(){
        try {
            users.add(new Usuario(Main.newNick, Main.newPwd, 0.0));
            System.out.println(Main.VERDE+"\n************REGISTRADO CORRECTAMENTE************"+Main.RESET);
            return true;
        } catch (Exception e) {
            System.out.println(Main.ROJO+"Algo salió mal"+Main.RESET);
            return false;
        }
        
    }

    public static Boolean setNewSaldo2(Double saldo){
        //si el nombre de usuario y la contraseña son iguales guardamos el saldo al usuario
        if(Objects.equals(Main.pwd, users.get(Main.ind).getPwd()) && Objects.equals(Main.nick, users.get(Main.ind).getNick())){
            users.get(Main.indTrans).saldo = saldo;
            return true;
            
        }
        //si algo no funciona
        return false;
    }


}

