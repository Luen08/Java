class Main {
    public static final String NEGRO = "\u001B[30m";
    public static final String ROJO = "\u001B[31m"; //blanco
    public static final String VERDE = "\u001B[32m";
    public static final String AMARILLO = "\u001B[33m";
    public static final String AZUL = "\u001B[34m";
    public static final String MORADO = "\u001B[35m";
    public static final String CELESTE = "\u001B[36m";
    public static final String BLANCO = "\u001B[37m"; //rojo
    public static final String RESET = "\u001B[0m";

    public static final String NEGRO_BACKGROUND = "\u001B[40m";
    public static final String ROJO_BACKGROUND = "\u001B[41m";
    public static final String VERDE_BACKGROUND = "\u001B[42m";
    public static final String AMARILLO_BACKGROUND = "\u001B[43m";
    public static final String AZUL_BACKGROUND = "\u001B[44m";
    public static final String MORADO_BACKGROUND = "\u001B[45m";
    public static final String CELESTE_BACKGROUND = "\u001B[46m";
    public static final String BLANCO_BACKGROUND = "\u001B[47m";

    static String nick, pwd, newNick, newPwd, userTrans;
    static double saldo;
    static int ind, indTrans;

    public static void main(String[] args) {
        Data_Base.Start(); // crear 1 objeto cliente
        Utilidades.icono();// mostrar nombre empresas Utilidades

        Loggin.mostrarOpcionesInicio();
        /*while (true) {
            int opl = Utilidades.recibir3();
            Loggin.mainLog(opl);
        }*/
        Loggin.start();

    }
}
