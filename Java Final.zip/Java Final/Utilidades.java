import java.io.*;
import java.util.Scanner;

public class Utilidades {

    static Scanner ingresar = new Scanner(System.in);

    public static void icono() {
        /*System.out.println("");
        System.out.println("\t\t\t\t\t"+"██████"+Main.ROJO+"╗░"+Main.RESET+"███████"+Main.ROJO+"╗"+Main.RESET+"██████"+Main.ROJO+"╗░"+Main.RESET+"██"+Main.ROJO+"╗░░░"+Main.RESET+"██"+Main.ROJO+"╗  "+Main.RESET+"██████"+Main.ROJO+"╗░░"+Main.RESET+"█████"+Main.ROJO+"╗░"+Main.RESET+"███"+Main.ROJO+"╗░░"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"╗░░"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET);
        System.out.println("\t\t\t\t\t"+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"╔════╝"+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"║░░░"+Main.RESET+"██"+Main.ROJO+"║  "+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"████"+Main.ROJO+"╗░"+Main.RESET+"██"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"║░"+Main.RESET+"██"+Main.ROJO+"╔╝"+Main.RESET);
        System.out.println("\t\t\t\t\t"+"██████"+Main.ROJO+"╔╝"+Main.RESET+"█████"+Main.ROJO+"╗░░"+Main.RESET+"██████"+Main.ROJO+"╔╝"+Main.RESET+"██"+Main.ROJO+"║░░░"+Main.RESET+"██"+Main.ROJO+"║  "+Main.RESET+"██████"+Main.ROJO+"╦╝"+Main.RESET+"███████"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"╔"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"║"+Main.RESET+"█████"+Main.ROJO+"═╝░"+Main.RESET);
        System.out.println("\t\t\t\t\t"+"██"+Main.ROJO+"╔═══╝░"+Main.RESET+"██"+Main.ROJO+"╔══╝░░"+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"║░░░"+Main.RESET+"██"+Main.ROJO+"║  "+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"╔══"+Main.RESET+"██"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"║╚"+Main.RESET+"████"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"╔═"+Main.RESET+"██"+Main.ROJO+"╗░"+Main.RESET);
        System.out.println("\t\t\t\t\t"+"██"+Main.ROJO+"║░░░░░"+Main.RESET+"███████"+Main.ROJO+"╗"+Main.RESET+"██"+Main.ROJO+"║░░"+Main.RESET+"██"+Main.ROJO+"║╚"+Main.RESET+"██████"+Main.ROJO+"╔╝  "+Main.RESET+"██████"+Main.ROJO+"╦╝"+Main.RESET+"██"+Main.ROJO+"║░░"+Main.RESET+"██"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"║░╚"+Main.RESET+"███"+Main.ROJO+"║"+Main.RESET+"██"+Main.ROJO+"║░╚"+Main.RESET+"██"+Main.ROJO+"╗"+Main.RESET);
        System.out.println("\t\t\t\t\t"+Main.ROJO+"╚═╝░░░░░╚══════╝╚═╝░░╚═╝░╚═════╝░  ╚═════╝░╚═╝░░╚═╝╚═╝░░╚══╝╚═╝░░╚═╝"+Main.RESET);
        System.out.println(" ");
        System.out.println("██╗███╗░░██╗████████╗███████╗██████╗░██████╗░░█████╗░███╗░░██╗██╗░░██╗");
        System.out.println("██║████╗░██║╚══██╔══╝██╔════╝██╔══██╗██╔══██╗██╔══██╗████╗░██║██║░██╔╝");
        System.out.println("██║██╔██╗██║░░░██║░░░█████╗░░██████╔╝██████╦╝███████║██╔██╗██║█████═╝░");
        System.out.println("██║██║╚████║░░░██║░░░██╔══╝░░██╔══██╗██╔══██╗██╔══██║██║╚████║██╔═██╗░");
        System.out.println("██║██║░╚███║░░░██║░░░███████╗██║░░██║██████╦╝██║░░██║██║░╚███║██║░╚██╗");
        System.out.println("╚═╝╚═╝░░╚══╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═╝░░╚══╝╚═╝░░╚═╝");*/
        System.out.println(Main.VERDE_BACKGROUND+"\n"+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.AZUL+"████"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"╗"+Main.RESET+Main.AZUL+"████"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"    ██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"███"+Main.NEGRO+"╗░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"████████"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"███████"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██████"+Main.NEGRO+"╗░"+Main.RESET+Main.VERDE_BACKGROUND+"██████"+Main.NEGRO+"╗░░"+Main.RESET+Main.VERDE_BACKGROUND+"█████"+Main.NEGRO+"╗░"+Main.RESET+Main.VERDE_BACKGROUND+"███"+Main.NEGRO+"╗░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗                                "+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"╔═╝╚═"+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"    ██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"████"+Main.NEGRO+"╗░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║╚══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══╝"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔════╝"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"████"+Main.NEGRO+"╗░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔╝                                "+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║    "+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"    ██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"█████"+Main.NEGRO+"╗░░"+Main.RESET+Main.VERDE_BACKGROUND+"██████"+Main.NEGRO+"╔╝"+Main.RESET+Main.VERDE_BACKGROUND+"██████"+Main.NEGRO+"╦╝"+Main.RESET+Main.VERDE_BACKGROUND+"███████"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"█████"+Main.NEGRO+"═╝░                                "+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║    "+Main.RESET+Main.AZUL+"██"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"    ██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║╚"+Main.RESET+Main.VERDE_BACKGROUND+"████"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══╝░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔══"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║╚"+Main.RESET+Main.VERDE_BACKGROUND+"████"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╔═"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗░                                "+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.AZUL+"████"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"╗"+Main.RESET+Main.AZUL+"████"+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"    ██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░╚"+Main.RESET+Main.VERDE_BACKGROUND+"███"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░░"+Main.RESET+Main.VERDE_BACKGROUND+"███████"+Main.NEGRO+"╗"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██████"+Main.NEGRO+"╦╝"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░░"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░╚"+Main.RESET+Main.VERDE_BACKGROUND+"███"+Main.NEGRO+"║"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"║░╚"+Main.RESET+Main.VERDE_BACKGROUND+"██"+Main.NEGRO+"╗                                "+Main.RESET);
        System.out.println(Main.VERDE_BACKGROUND+"                                "+Main.RESET+Main.VERDE_BACKGROUND+Main.NEGRO+"╚═══╝╚═══╝    ╚═╝╚═╝░░╚══╝░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═╝░░╚══╝╚═╝░░╚═╝                                "+Main.RESET);
    }   
    

    public static String nextNick() {
        String d;

        System.out.print("\n"+Main.VERDE+"Ingresa tu nick: "+Main.RESET);
        d = ingresar.nextLine();
        return d;
    }
    
    public static String nextPwd(String prompt){
        //crear objeto de consola
        Console consola = System.console();
        //read pwd
        //array de pwd
        
        char[] ch = consola.readPassword(prompt);
        return String.valueOf(ch);
        
    }

    public static int recibir5(){
        String nes; //numero escrito string
        int nei; // numero escrito integer
        // debe retornar numero del 1 al 4 de lo contrario ciclo while

        while (true) {
            System.out.println("\nIngresa numero de accion:");
            System.out.print(Main.VERDE+"> "+Main.RESET);
            nes = ingresar.nextLine();
            try {
                nei = Integer.parseInt(nes);
                if (nei <= 0 || nei > 5) {
                    throw new NumberFormatException();
                }
                break;
            } catch (NumberFormatException nfe) {
                System.out.println(Main.ROJO+"OPCIONES PERMITIDAS "+Main.RESET+Main.VERDE+"["+Main.RESET+"1"+Main.VERDE+"]"+Main.RESET+Main.VERDE+"["+Main.RESET+"2"+Main.VERDE+"]"+Main.RESET+Main.VERDE+"["+Main.RESET+"3"+Main.VERDE+"]"+Main.RESET+Main.VERDE+"["+Main.RESET+"4"+Main.VERDE+"]"+Main.RESET);
            }
        }
        return nei;
    }

    public static double recibirDouble(String prompt){
        String ns;
        double n;
        // retorna double con un String
        while (true) {
            System.out.println(prompt);
            System.out.print(Main.VERDE+"> $"+Main.RESET);
            ns = ingresar.nextLine();
            try {
                n = Double.parseDouble(ns);
                if(n <= 0){
                    throw new NumberFormatException();
                }
                break;
            } catch (NumberFormatException nfe) {
                System.out.println(Main.ROJO+"Algo salió mal, prueba con numeros validos"+Main.RESET);
            }
        }
        return n;
    }

    public static int recibir3(){
        String nls; // numero de loggin string
        int nli; //numero de login integer
        while (true) {
            System.out.println("\nIngresa la acción a realizar:");
            System.out.print(Main.VERDE+"> "+Main.RESET);
            nls = ingresar.nextLine();
            try {
                nli = Integer.parseInt(nls);
                if (nli <= 0 || nli > 3) {
                    throw new NumberFormatException();
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println(Main.ROJO+"OPCIONES PERMITIDAS "+Main.RESET+Main.VERDE+"["+Main.RESET+"1"+Main.VERDE+"]"+Main.RESET+Main.VERDE+"["+Main.RESET+"2"+Main.VERDE+"]"+Main.RESET+Main.VERDE+"["+Main.RESET+"3"+Main.VERDE+"]"+Main.RESET);
            }
        }
        return nli;
    }

    public static String recibirString(){
        String userTrans;
        System.out.println("Ingresa el nick de la cuenta: ");
        userTrans = ingresar.nextLine();
        
        return userTrans;

    }
    
    
}
