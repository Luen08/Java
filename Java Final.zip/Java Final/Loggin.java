public class Loggin {
    static void mostrarOpcionesInicio(){
        System.out.println("");
        System.out.println(Main.VERDE+"["+Main.RESET+"1"+Main.VERDE+"]"+Main.RESET+" Iniciar sesión");
        System.out.println(Main.VERDE+"["+Main.RESET+"2"+Main.VERDE+"]"+Main.RESET+" Registrate ");
        System.out.println(Main.VERDE+"["+Main.RESET+"3"+Main.VERDE+"]"+Main.RESET+" Salir");
    }

    static void mainLog(int l){
        switch (l) {
            case 1:
                inicio();
                break;
            case 2:
                registro();
                break;
            case 3:
                salirLog();
                break;
        }
    } 

    static private void inicio(){
        do {
            Main.nick = Utilidades.nextNick();//Ingreso de nick en bank utils 
        } while (!Data_Base.findUser(Main.nick));//buscamos el nick correcto
        
        if(Data_Base.checkPwd()){
            System.out.println("\n"+Main.VERDE+"BIENVENIDO "+Main.RESET+Main.nick);
            Operaciones.mostrarOpciones(); //muestro opciones
            while (true) {
                int op = Utilidades.recibir5();
                Operaciones.main(op);
            }
        }
    }

    static private void registro(){
        System.out.println(Main.VERDE+"\n************FORMULARIO DE REGISTRO************"+Main.RESET);
        do {
            Main.newNick = Utilidades.nextNick(); // Ingreso nick 
        } while (!Data_Base.findUserLog(Main.newNick)); // si está en algun usuario retorna false, si no esta retorna true
        
        
        Main.newPwd = Utilidades.nextPwd(Main.VERDE+"Ingresa nueva contraseña: "+Main.RESET);
        Data_Base.registro();
    }

    static public void salirLog(){
        System.out.println(Main.VERDE+"Gracias por su preferencia. Hasta pronto tqm"+Main.RESET);
        System.exit(0);
    }

    static public void start(){
        while (true) {
            int opl = Utilidades.recibir3();
            Loggin.mainLog(opl);
        }
    }
}
