public class Usuario {
    //ATRIBUTOS
    private final String nick, pwd;
    
    double saldo;
    
    //CONSTRUCTOR
    Usuario(String nick, String pwd, double saldo){
        this.nick = nick;
        this.pwd = pwd;
        this.saldo = saldo;
    }
    //METODO

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String getNick() {
        return nick;
    }

    public String getPwd() {
        return pwd;
    }

    public double getSaldo() {
        return saldo;
    }
        
}
