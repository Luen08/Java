import java.util.concurrent.TimeUnit;
public class Operaciones {
    static void mostrarOpciones(){
        System.out.println("");
        System.out.println(Main.VERDE+"["+Main.RESET+"1"+Main.VERDE+"]"+Main.RESET+" Deposito");
        System.out.println(Main.VERDE+"["+Main.RESET+"2"+Main.VERDE+"]"+Main.RESET+" Retiro");
        System.out.println(Main.VERDE+"["+Main.RESET+"3"+Main.VERDE+"]"+Main.RESET+" Consulta de saldo");
        System.out.println(Main.VERDE+"["+Main.RESET+"4"+Main.VERDE+"]"+Main.RESET+" Transferencia");
        System.out.println(Main.VERDE+"["+Main.RESET+"5"+Main.VERDE+"]"+Main.RESET+" Cerrar Sesion");
    }

    static void main(int f){
        switch (f) {
            case 1:
                Deposito();
                break;
            case 2:
                Retiro();
                break;
            case 3:
                mostrarSaldo();
                break;
            case 4:
                transferencia();
                break;
            case 5:
                cerrarSesion();
                break;
        }
    } 

    static private void Deposito(){ // deposito
        mostrarSaldo();
        //convalida si es double o no
        double n = Utilidades.recibirDouble("Ingresa el dinero a depositar: ");
        
        double nuevoSaldo = Main.saldo+n;
        if (Data_Base.setNewSaldo(nuevoSaldo)) {// pregunta si es posible con la función set
            Main.saldo = nuevoSaldo;
            System.out.println(Main.VERDE+"Deposito realizado correctamente!"+Main.RESET);
            return;
        }
        System.out.println(Main.ROJO+"Algo salió mal"+Main.RESET);
    }

    static private void Retiro(){//retiro 
        mostrarSaldo();
        double n = Utilidades.recibirDouble("Ingresa el dinero a retirar: "); // convalida y pide al mismo tiempo
        if (n > Main.saldo) { // si se retira una cantidad mayor, se corta
            System.out.println(Main.ROJO+"No cuenta con fondos suficientes..."+Main.RESET);
            return;
        }
        double nuevoSaldo = Main.saldo-n;
        if (Data_Base.setNewSaldo(nuevoSaldo)) {//pregunta si se puede setear el saldo
            Main.saldo = nuevoSaldo; //actualiza el saldo
            System.out.println(Main.VERDE+"Retiro realizado correctamente!"+Main.RESET);
            return;
        }
        System.out.println(Main.ROJO+"Algo salio mal.."+Main.RESET);
    }
    
    static public void mostrarSaldo(){// muestra saldo
        System.out.println("\n"+Main.VERDE+"Saldo disponible: $"+Main.RESET+Main.saldo);
    }

    static public void transferencia(){
        mostrarSaldo();
        
        do {
            Main.userTrans = Utilidades.recibirString();
        } while (!Data_Base.findUserTrans(Main.userTrans));

            
            double n = Utilidades.recibirDouble("Ingresa la cantidad a transferir: ");
            if (n > Main.saldo) { // si se retira una cantidad mayor, se corta
                System.out.println(Main.ROJO+"No cuenta con fondos suficientes..."+Main.RESET);
                return;
            }
            double nuevoSaldo = Main.saldo - n;
            if (Data_Base.setNewSaldo(nuevoSaldo)) {//pregunta si se puede setear el saldo
                Main.saldo = nuevoSaldo; //actualiza el saldo
            }
            double nuevoSaldo2 = Data_Base.users.get(Main.indTrans).getSaldo() + n;
            if (Data_Base.setNewSaldo2(nuevoSaldo2)) {//pregunta si se puede setear el saldo
                Data_Base.users.get(Main.indTrans).saldo = nuevoSaldo2; //actualiza el saldo
            }
            System.out.println("Transferencia realizada");
            return;

    
    }

    static public void cerrarSesion(){// termina programa
        System.out.println(Main.VERDE+"Cerrando Sesion"+Main.RESET);
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            
        }
        
        Loggin.mostrarOpcionesInicio();
        Loggin.start();
    }
}
